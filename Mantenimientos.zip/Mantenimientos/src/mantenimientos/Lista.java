package mantenimientos;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Toolkit;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

public class Lista extends javax.swing.JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnAgregar; // Botón para agregar registros
    private JButton btnFiltrarProximos;
    private JButton btnFiltrarVencidos;
    private JButton btnVistaGeneral;
    private JLabel lblProximosAVencer;
    private JLabel lblVencidos;
    private boolean primeraCarga = true; // Bandera para controlar la primera carga
    private JLabel lblTotalHerramentales; // JLabel para mostrar el total de herramentales
    

public Lista() {
    // Configuración de la ventana
    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    setTitle("Lista de Herramentales");
    setPreferredSize(new Dimension(1700, 900));
    setResizable(false);
    setIconImage(getIconImage());
    
    // Inicializar el modelo de la tabla
    model = new DefaultTableModel(new String[]{
        "EIN o TL", "Descripción", "Mantenimiento Anterior", 
        "Fecha del próximo mantenimiento", "Dueño del herramental", 
        "Ubicación", "Frecuencia de mantenimiento"
    }, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false; // Todas las celdas no son editables
        }
    };

    
// Inicializar la tabla
table = new JTable(model) {
    @Override
    public TableCellRenderer getCellRenderer(int row, int column) {
        if (column == 3) { // Solo para la columna de fecha
            return new ColorCenteredRenderer(); // Retorna el nuevo renderizador combinado
        }
        return super.getCellRenderer(row, column); // Para otras columnas, usa el renderizador por defecto
    }
};

// Ajustar el ancho de las columnas
table.getColumnModel().getColumn(0).setPreferredWidth(50); // EIN o TL
table.getColumnModel().getColumn(1).setPreferredWidth(200); // Descripción
table.getColumnModel().getColumn(2).setPreferredWidth(70); // Mantenimiento Anterior
table.getColumnModel().getColumn(3).setPreferredWidth(130); // Fecha del próximo mantenimiento
table.getColumnModel().getColumn(4).setPreferredWidth(70); // Dueño del herramental
table.getColumnModel().getColumn(5).setPreferredWidth(200); // Ubicación
table.getColumnModel().getColumn(6).setPreferredWidth(100); // Frecuencia de mantenimiento

    // Centrar los encabezados de las columnas
    DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(JLabel.CENTER); // Centrar el texto
            setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK)); // Mantener el borde inferior
            return c;
        }
    };
    headerRenderer.setHorizontalAlignment(JLabel.CENTER);
    for (int i = 0; i < model.getColumnCount(); i++) {
        table.getTableHeader().getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
    }

    // Aplicar CenteredCellRenderer a las otras columnas si es necesario
    CenteredCellRenderer centeredRenderer = new CenteredCellRenderer();
    for (int i = 0; i < model.getColumnCount(); i++) {
        if (i != 3) { // No aplicar a la columna de fecha
            table.getColumnModel().getColumn(i).setCellRenderer(centeredRenderer);
        }
    }

    // Configurar la cuadrícula
    table.setShowGrid(true);
    table.setGridColor(Color.BLACK);
    table.setIntercellSpacing(new Dimension(1, 1));

    // Crear el JScrollPane para la tabla
    JScrollPane scrollPane = new JScrollPane(table);

    // Inicializar los botones
    btnActualizar = new JButton("Actualizar");
    btnEliminar = new JButton("Eliminar");
    btnAgregar = new JButton("Agregar");
    btnFiltrarProximos = new JButton("Filtrar Próximos a Vencer");
    btnFiltrarVencidos = new JButton("Filtrar Vencidos");
    btnVistaGeneral = new JButton("Vista General");

    // Agregar ActionListeners a los botones
    btnAgregar.addActionListener(evt -> agregarRegistro());
    btnActualizar.addActionListener(evt -> actualizarRegistro());
    btnEliminar.addActionListener(evt -> eliminarRegistro());
    btnFiltrarProximos.addActionListener(evt -> filtrarProximosAVencer());
    btnFiltrarVencidos.addActionListener(evt -> filtrarVencidos());
    btnVistaGeneral.addActionListener(evt -> {
        model.setRowCount(0); // Limpiar el modelo de la tabla
        cargarDatos(); // Cargar todos los datos nuevamente desde el archivo
        btnFiltrarProximos.setEnabled(true);
        btnFiltrarVencidos.setEnabled(true);
        table.setModel(model); // Restablecer el modelo de la tabla a su estado original
        aplicarRenderizadorEncabezado();
        aplicarCentrado(); // Aplicar centrado a todas las
    });

    // Crear el botón de información
    JButton btnInfo = new JButton("i");
    btnInfo.setPreferredSize(new Dimension(35, 35));
    btnInfo.setToolTipText("Información"); // Tooltip para el botón

    // Agregar ActionListener al botón de información
    btnInfo.addActionListener(evt -> {
                JOptionPane.showMessageDialog(null, "     Program Created by " + "\n" + "          Oscar Lopez" + "\n" + "\n" + "               Contact" + "\n" + "Oscar.Lopez@plexus.com" , "Developer",JOptionPane.INFORMATION_MESSAGE);
    });

    // Crear un panel para el botón de información y agregarlo a la esquina
    JPanel panelInfo = new JPanel();
    panelInfo.add(btnInfo);
    panelInfo.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espaciado alrededor del panel

    // Crear un panel para la etiqueta de bienvenida y centrarla
    JPanel panelBienvenida = new JPanel();
    String nombreUsuario = System.getProperty("user.name");
    JLabel lblBienvenido = new JLabel("                                                                                                                                        Bienvenid@ " + nombreUsuario);
    lblBienvenido.setFont(lblBienvenido.getFont().deriveFont(19f)); // Aumentar el tamaño de la fuente
    panelBienvenida.add(lblBienvenido);
    panelBienvenida.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Espaciado alrededor del panel
    panelBienvenida.setLayout(new BoxLayout(panelBienvenida, BoxLayout.X_AXIS)); // Usar BoxLayout para centrar

    // Crear un panel para contener la etiqueta de bienvenida y el panel de información
    JPanel topPanel = new JPanel(new BorderLayout());
    topPanel.add(panelBienvenida, BorderLayout.CENTER); // Agregar el panel de bienvenida al centro
    topPanel.add(panelInfo, BorderLayout.EAST); // Agregar el panel de información a la derecha

    // Crear un panel para los botones
    JPanel panelBotones = new JPanel();
    panelBotones.add(btnAgregar);
    panelBotones.add(btnActualizar);
    panelBotones.add(btnEliminar);
    panelBotones.add(btnFiltrarProximos);
    panelBotones.add(btnFiltrarVencidos);
    panelBotones.add(btnVistaGeneral);

    // Crear un panel para las etiquetas
    JPanel panelEtiquetas = new JPanel();
    panelEtiquetas.setLayout(new BoxLayout(panelEtiquetas, BoxLayout.Y_AXIS)); // Establecer un BoxLayout vertical
    
// Crear y configurar las etiquetas
lblTotalHerramentales = new JLabel("Total de herramentales: 0");
lblTotalHerramentales.setFont(lblTotalHerramentales.getFont().deriveFont(16f)); // Aumentar el tamaño de la fuente
panelEtiquetas.add(lblTotalHerramentales); // Agregar al panel de etiquetas
panelEtiquetas.add(Box.createVerticalStrut(10)); // Espacio vertical de 10 píxeles

lblProximosAVencer = new JLabel("Mantenimientos próximos a vencer: 0");
lblProximosAVencer.setFont(lblProximosAVencer.getFont().deriveFont(16f)); // Aumentar el tamaño de la fuente
panelEtiquetas.add(lblProximosAVencer); // Agregar al panel de etiquetas
panelEtiquetas.add(Box.createVerticalStrut(10)); // Espacio vertical de 10 píxeles

lblVencidos = new JLabel("Mantenimientos vencidos: 0");
lblVencidos.setFont(lblVencidos.getFont().deriveFont(16f)); // Aumentar el tamaño de la fuente
panelEtiquetas.add(lblVencidos); // Agregar al panel de etiquetas
    
    // Añadir las etiquetas al panel
    panelEtiquetas.add(lblProximosAVencer);
    panelEtiquetas.add(Box.createVerticalStrut(10)); // Espacio vertical de 10 píxeles
    panelEtiquetas.add(lblVencidos);
    panelEtiquetas.add(Box.createVerticalStrut(10)); // Espacio vertical de 10 píxeles

    // Agregar un borde vacío al panel
    panelEtiquetas.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

    // Crear un panel para los indicadores
    JPanel panelIndicadores = new JPanel();
    panelIndicadores.setLayout(new GridBagLayout()); // Usar GridBagLayout para mejor alineación
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(5, 5, 5, 5); // Espaciado entre componentes

    // Indicador de vencidos
    JPanel panelVencido = new JPanel();
    panelVencido.setBackground(Color.RED); // Color rojo para vencidos
    panelVencido.setPreferredSize(new Dimension(20, 20)); // Tamaño del indicador
    panelVencido.setMaximumSize(new Dimension(20, 20)); // Asegurarse de que no se expanda
    panelVencido.setMinimumSize(new Dimension(20, 20)); // Asegurarse de que no se expanda

    gbc.gridx = 0; // Columna 0
    gbc.gridy = 0; // Fila 0
    panelIndicadores.add(panelVencido, gbc); // Añadir el cuadro al panel de indicadores

    JLabel lblVencido = new JLabel("Vencido");
    lblVencido.setFont(lblVencido.getFont().deriveFont(15f)); // Tamaño de fuente más pequeño
    gbc.gridx = 1; // Columna 1
    gbc.gridy = 0; // Fila 0
    panelIndicadores.add(lblVencido, gbc); // Añadir la etiqueta
        JPanel panelPorVencer = new JPanel();
    panelPorVencer.setBackground(Color.YELLOW); // Color amarillo para por vencer
    panelPorVencer.setPreferredSize(new Dimension(20, 20)); // Tamaño del indicador
    panelPorVencer.setMaximumSize(new Dimension(20, 20)); // Asegurarse de que no se expanda
    panelPorVencer.setMinimumSize(new Dimension(20, 20)); // Asegurarse de que no se expanda

    gbc.gridx = 0; // Columna 0
    gbc.gridy = 1; // Fila 1
    panelIndicadores.add(panelPorVencer, gbc); // Añadir el cuadro al panel de indicadores

    JLabel lblPorVencer = new JLabel("Por vencer");
    lblPorVencer.setFont(lblPorVencer.getFont().deriveFont(15f)); // Tamaño de fuente más pequeño
    gbc.gridx = 1; // Columna 1
    gbc.gridy = 1; // Fila 1
    panelIndicadores.add(lblPorVencer, gbc); // Añadir la etiqueta al lado del cuadro

    // Añadir el panel de indicadores al panel de etiquetas
    panelEtiquetas.add(panelIndicadores);

    // Añadir los paneles al contenedor principal
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(topPanel, BorderLayout.NORTH); // Panel superior con bienvenida y botón de info
    getContentPane().add(scrollPane, BorderLayout.CENTER); // Panel de la tabla
    getContentPane().add(panelBotones, BorderLayout.SOUTH); // Panel de botones
    getContentPane().add(panelEtiquetas, BorderLayout.EAST); // Panel de etiquetas
    
    // Ajustar el tamaño de la ventana
    pack();
    setLocationRelativeTo(null); // Centrar la ventana en la pantalla

    // Cargar los datos iniciales
    cargarDatos();
}

    @Override
    public Image getIconImage(){
         Image retValue = Toolkit.getDefaultToolkit().getImage(ClassLoader.getSystemResource("img/mantenimiento.png"));
         
         
         return retValue;
    }
        
      
private void agregarRegistro() {
    // Crear un panel para los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    JTextField txtEinTl = new JTextField();
    JTextField txtDescripcion = new JTextField();
    JTextField txtIngeniero = new JTextField();
    JTextField txtUbicacion = new JTextField();
    
    // Crear un JComboBox para la frecuencia de mantenimiento
    String[] frecuencias = {"Semanal", "Mensual", "Anual", "Trimestral", "Semestral"};
    JComboBox<String> comboFrecuencia = new JComboBox<>(frecuencias);
    
    // Crear un JDateChooser para la fecha de mantenimiento
    JDateChooser dateChooser = new JDateChooser();
    dateChooser.setPreferredSize(new Dimension(200, 25)); // Establecer el tamaño preferido

    panel.add(new JLabel("EIN o TL:"));
    panel.add(txtEinTl);
    panel.add(new JLabel("Descripción:"));
    panel.add(txtDescripcion);
    panel.add(new JLabel("Dueño del herramental:"));
    panel.add(txtIngeniero);
    panel.add(new JLabel("Ubicación:"));
    panel.add(txtUbicacion);
    panel.add(new JLabel("Frecuencia:"));
    panel.add(comboFrecuencia);
    panel.add(new JLabel("Fecha del proximo mantenimiento:"));
    panel.add(dateChooser);

    int result = JOptionPane.showConfirmDialog(this, panel, "Agregar Herramental", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

    if (result == JOptionPane.OK_OPTION) {
        String einTl = txtEinTl.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String ingeniero = txtIngeniero.getText().trim();
        String ubicacion = txtUbicacion.getText().trim();
        String frecuencia = (String) comboFrecuencia.getSelectedItem();

        // Obtener la fecha seleccionada
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String fechaMantenimiento = sdf.format(dateChooser.getDate());

        // Agregar un campo "N/A" para el mantenimiento anterior
        String mantenimientoAnterior = "N/A"; 

        // Agregar el nuevo registro a la tabla
        model.addRow(new Object[]{einTl, descripcion, mantenimientoAnterior, fechaMantenimiento, ingeniero, ubicacion, frecuencia});
        guardarDatos(); // Guardar el nuevo registro en el archivo
        cargarDatos(); // Recargar los datos para actualizar los JLabel

    } else {
        JOptionPane.showMessageDialog(this, "Operación cancelada.");
    }
}
           
private void cargarDatos() {
    model.setRowCount(0); // Limpiar el modelo antes de cargar nuevos datos
    int totalHerramentales = 0; // Contador para los herramentales

    try (BufferedReader br = new BufferedReader(new FileReader("H:\\mantenimientos.csv"))) {
        String linea;
        int mantenimientosProximosAVencer = 0;
        int mantenimientosVencidos = 0;

        while ((linea = br.readLine()) != null) {
            String[] datos = linea.split(",");
            if (datos.length < 7) {
                System.err.println("Error: Línea con datos insuficientes: " + linea);
                continue; // Salta esta línea y continúa con la siguiente
            }

            String einOTl = datos[0].trim();
            String descripcion = datos[1].trim();
            String mantenimientoAnterior = datos[2].trim();
            String fechaMantenimiento = datos[3].trim();
            String ingeniero = datos[4].trim();
            String ubicacion = datos[5].trim();
            String frecuencia = datos[6].trim();
            model.addRow(new Object[]{einOTl, descripcion, mantenimientoAnterior, fechaMantenimiento, ingeniero, ubicacion, frecuencia});

            totalHerramentales++; // Incrementar el contador de herramentales

            // Contar mantenimientos
            if (isFechaVencida(fechaMantenimiento)) {
                mantenimientosVencidos++;
            } else if (isFechaProxima(fechaMantenimiento)) {
                mantenimientosProximosAVencer++;
            }
        }

        // Actualizar el JLabel con el total de herramentales
        lblTotalHerramentales.setText("Total de herramentales: " + totalHerramentales);
        lblProximosAVencer.setText("Mantenimientos próximos a vencer: " + mantenimientosProximosAVencer);
        lblVencidos.setText("Mantenimientos vencidos: " + mantenimientosVencidos);

        // Mostrar mensajes según los conteos solo si es la primera carga
        if (primeraCarga) {
            if (mantenimientosProximosAVencer == 0 && mantenimientosVencidos == 0) {
                JOptionPane.showMessageDialog(this, "¡Felicidades! No tienes mantenimientos vencidos ni próximos a vencer.");
            } else if (mantenimientosVencidos > 0 || mantenimientosProximosAVencer > 0) {
                JOptionPane.showMessageDialog(this, "ATIENDE TUS MANTENIMIENTOS LO ANTES POSIBLE.");
            }
            primeraCarga = false; // Cambiar la bandera a false después de la primera carga
            
        }

    } catch (FileNotFoundException e) {
        // Mostrar un mensaje de error si el archivo no se encuentra
        JOptionPane.showMessageDialog(this, "Archivo no encontrado. Revisa que el archivo se encuentre en la ruta: H:\\mantenimientos.csv \n \n "
                + "Si es primera vez que usas la aplicación haz caso omiso \n \n "
                + "              En caso de no tener agregado el disco H contacta a IT \n ​\n            AMER - Mexico          Ext.9900          Num: 52-33-3777-9900" , "Error", JOptionPane.ERROR_MESSAGE);
    } catch (IOException e) {
        // Manejar otras excepciones de entrada/salida
        JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void actualizarRegistro() {
    int selectedRow = table.getSelectedRow();
    if (selectedRow >= 0) {
        // Obtener el índice original del modelo
        int originalRow = getOriginalRowIndex(selectedRow);
        if (originalRow < 0) {
            JOptionPane.showMessageDialog(this, "Error al encontrar el índice original.");
            return; // Salir si no se encuentra el índice
        }

        // Crear un panel para el cuadro de diálogo
        JPanel panel = new JPanel(new GridLayout(0, 2));
        
        // Obtener los valores actuales de la fila seleccionada
        String tlOein = (String) model.getValueAt(originalRow, 0); // TL o EIN
        String descripcion = (String) model.getValueAt(originalRow, 1); // Descripción
        String fechaMantenimiento = (String) model.getValueAt(originalRow, 3); // Fecha Mantenimiento
        String duenioHerramental = (String) model.getValueAt(originalRow, 4); // Dueño del herramental
        String ubicacion = (String) model.getValueAt(originalRow, 5); // Ubicación
        String frecuencia = (String) model.getValueAt(originalRow, 6); // Frecuencia

        // Crear campos de entrada para cada uno de los datos
        JTextField txtEinTl = new JTextField(tlOein);
        JTextField txtDescripcion = new JTextField(descripcion);
        
        // Crear un JDateChooser para la fecha de mantenimiento
        JDateChooser dateChooser = new JDateChooser();
        // Establecer la fecha mínima como la fecha actual
        dateChooser.setMinSelectableDate(new Date());
        // Establecer la fecha actual en el JDateChooser
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            Date date = sdf.parse(fechaMantenimiento);
            dateChooser.setDate(date);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        JTextField txtIngeniero = new JTextField(duenioHerramental);
        JTextField txtUbicacion = new JTextField(ubicacion);
        
        // Crear un JComboBox para la frecuencia de mantenimiento
        String[] frecuencias = {"Semanal", "Mensual", "Anual", "Trimestral", "Semestral"};
        JComboBox<String> comboFrecuencia = new JComboBox<>(frecuencias);
        comboFrecuencia.setSelectedItem(frecuencia); // Establecer la frecuencia actual

        // Agregar los campos al panel
        panel.add(new JLabel("EIN o TL:"));
        panel.add(txtEinTl);
        panel.add(new JLabel("Descripción:"));
        panel.add(txtDescripcion);
        panel.add(new JLabel("Fecha del proximo mantenimiento:"));
        panel.add(dateChooser); // Agregar el JDateChooser
        panel.add(new JLabel("Dueño del herramental:"));
        panel.add(txtIngeniero);
        panel.add(new JLabel("Ubicación:"));
        panel.add(txtUbicacion);
        panel.add(new JLabel("Frecuencia:"));
        panel.add(comboFrecuencia);

        // Mostrar el cuadro de diálogo para actualizar
        int result = JOptionPane.showConfirmDialog(this, panel, "Actualizar Mantenimiento", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result == JOptionPane.OK_OPTION) {
            // Obtener los nuevos valores ingresados
            String einTl = txtEinTl.getText().trim();
            String descripcionNueva = txtDescripcion.getText().trim();
            
            // Obtener la fecha seleccionada del JDateChooser
            Date fechaSeleccionada = dateChooser.getDate();
            String fechaMantenimientoNueva = null;
            if (fechaSeleccionada != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                fechaMantenimientoNueva = sdf.format(fechaSeleccionada); // Formatear la fecha
            } else {
                JOptionPane.showMessageDialog(this, "Por favor, seleccione una fecha válida.");
                return; // Salir si no se selecciona una fecha
            }

            String ingenieroNuevo = txtIngeniero.getText().trim();
            String ubicacionNueva = txtUbicacion.getText().trim();
            String frecuenciaNueva = (String) comboFrecuencia.getSelectedItem();
            // Guardar la fecha de mantenimiento actual en el campo de mantenimiento anterior
            String mantenimientoAnteriorNuevo = fechaMantenimiento; // Guardar la fecha anterior

            // Actualizar los valores en el modelo original
                       model.setValueAt(einTl, originalRow, 0);
            model.setValueAt(descripcionNueva, originalRow, 1);
            model.setValueAt(mantenimientoAnteriorNuevo, originalRow, 2); // Actualizar el mantenimiento anterior
            model.setValueAt(fechaMantenimientoNueva, originalRow, 3); // Actualizar la fecha
            model.setValueAt(ingenieroNuevo, originalRow, 4);
            model.setValueAt(ubicacionNueva, originalRow, 5);
            model.setValueAt(frecuenciaNueva, originalRow, 6);

            // Guardar los cambios en el archivo
            if (guardarDatos()) { // Asegúrate de que guardarDatos devuelva un booleano
                cargarDatos(); // Recargar datos para actualizar la tabla y los JLabel
            } else {
                JOptionPane.showMessageDialog(this, "Error al guardar los cambios.");
            }
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione un registro para actualizar.");
    }
}
                

private void actualizarDatos(int originalRow) {
    // Aquí va la lógica que ya tenías para actualizar la fecha
    String fechaMantenimiento = (String) model.getValueAt(originalRow, 3); // Fecha actual
    JDateChooser dateChooser = new JDateChooser();
    try {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        dateChooser.setDate(sdf.parse(fechaMantenimiento)); // Establecer la fecha actual
    } catch (ParseException e) {
        e.printStackTrace();
    }
    // Establecer la fecha mínima seleccionable como el día actual
    dateChooser.setMinSelectableDate(new Date()); // No se puede seleccionar una fecha anterior al día actual

    JPanel panel = new JPanel(new GridLayout(0, 2));
    panel.add(new JLabel("Fecha Mantenimiento:"));
    panel.add(dateChooser);

    int result = JOptionPane.showConfirmDialog(this, panel, "Actualizar Mantenimiento", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String nuevaFechaMantenimiento = sdf.format(dateChooser.getDate());

        // Actualizar la fecha en el modelo original
        model.setValueAt(nuevaFechaMantenimiento, originalRow, 3); // Cambiar a nuevaFechaMantenimiento

        guardarDatos(); // Guardar los cambios en el archivo
        cargarDatos(); // Recargar datos para actualizar la tabla y los JLabel
    }
}

private void editarDatos(int selectedRow) {
    // Verificar que la fila seleccionada sea válida
    if (selectedRow < 0 || selectedRow >= table.getRowCount()) {
        JOptionPane.showMessageDialog(this, "Por favor, selecciona un registro válido para editar.");
        return;
    }

    // Obtener el índice original del modelo
    int originalRow = getOriginalRowIndex(selectedRow);
    if (originalRow < 0 || originalRow >= model.getRowCount()) {
        JOptionPane.showMessageDialog(this, "Error al encontrar el índice original.");
        return; // Salir si no se encuentra el índice
    }

    // Obtener los valores actuales de la fila seleccionada
    String tlOein = (String) model.getValueAt(originalRow, 0); // TL o EIN
    String descripcion = (String) model.getValueAt(originalRow, 1); // Descripción
    String mantenimientoAnterior = (String) model.getValueAt(originalRow, 2); // Mantenimiento Anterior
    String fechaMantenimiento = (String) model.getValueAt(originalRow, 3); // Fecha Mantenimiento
    String duenioHerramental = (String) model.getValueAt(originalRow, 4); // Dueño del herramental
    String ubicacion = (String) model.getValueAt(originalRow, 5); // Ubicación
    String frecuencia = (String) model.getValueAt(originalRow, 6); // Frecuencia

    // Crear un panel para los campos de entrada
    JPanel panel = new JPanel(new GridLayout(0, 2));

    JTextField txtEinTl = new JTextField(tlOein);
    JTextField txtDescripcion = new JTextField(descripcion);
    JTextField txtMantenimientoAnterior = new JTextField(mantenimientoAnterior);
    JTextField txtIngeniero = new JTextField(duenioHerramental);
    JTextField txtUbicacion = new JTextField(ubicacion);
    
    // Crear un JComboBox para la frecuencia de mantenimiento
    String[] frecuencias = {"Semanal", "Mensual", "Anual", "Trimestral", "Semestral"};
    JComboBox<String> comboFrecuencia = new JComboBox<>(frecuencias);
    comboFrecuencia.setSelectedItem(frecuencia); // Establecer la frecuencia actual

    panel.add(new JLabel("EIN o TL:"));
    panel.add(txtEinTl);
    panel.add(new JLabel("Descripción:"));
    panel.add(txtDescripcion);
    panel.add(new JLabel("Mantenimiento Anterior:"));
    panel.add(txtMantenimientoAnterior);
    panel.add(new JLabel("Fecha Mantenimiento:"));
    panel.add(new JLabel(fechaMantenimiento)); // Mostrar la fecha actual como etiqueta
    panel.add(new JLabel("Dueño del herramental:"));
    panel.add(txtIngeniero);
    panel.add(new JLabel("Ubicación:"));
    panel.add(txtUbicacion);
    panel.add(new JLabel("Frecuencia:"));
    panel.add(comboFrecuencia);

    // Mostrar el cuadro de diálogo para editar
    int result = JOptionPane.showConfirmDialog(this, panel, "Editar Registro", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (result == JOptionPane.OK_OPTION) {
        // Obtener los nuevos valores ingresados
        String einTl = txtEinTl.getText().trim();
        String descripcionNueva = txtDescripcion.getText().trim();
        String mantenimientoAnteriorNuevo = txtMantenimientoAnterior.getText().trim();
        String ingenieroNuevo = txtIngeniero.getText().trim();
        String ubicacionNueva = txtUbicacion.getText().trim();
        String frecuenciaNueva = (String) comboFrecuencia.getSelectedItem();

        // Actualizar los valores en el modelo original
        model.setValueAt(einTl, originalRow, 0);
        model.setValueAt(descripcionNueva, originalRow, 1);
        model.setValueAt(mantenimientoAnteriorNuevo, originalRow, 2);
        model.setValueAt(fechaMantenimiento, originalRow, 3); // No se cambia la fecha
        model.setValueAt(ingenieroNuevo, originalRow, 4);
        model.setValueAt(ubicacionNueva, originalRow, 5);
        model.setValueAt(frecuenciaNueva, originalRow, 6);

        // Guardar los cambios en el archivo
        if (guardarDatos()) { // Asegúrate de que guardarDatos devuelva un booleano
            cargarDatos(); // Recargar datos para actualizar la tabla y los JLabel
        } else {
            JOptionPane.showMessageDialog(this, "Error al guardar los cambios.");
        }
    }
}

private int getOriginalRowIndex(int filteredRowIndex) {
    // Si no hay filtro aplicado, simplemente retornamos el índice
    if (!btnFiltrarProximos.isEnabled() && !btnFiltrarVencidos.isEnabled()) {
        return filteredRowIndex;
    }

    // Obtener el valor de la fila filtrada
    String einOTlFiltrado = (String) table.getValueAt(filteredRowIndex, 0); // Suponiendo que el EIN o TL está en la columna 0

    // Buscar el índice en el modelo original
    for (int i = 0; i < model.getRowCount(); i++) {
        String einOTlOriginal = (String) model.getValueAt(i, 0);
        if (einOTlOriginal.equals(einOTlFiltrado)) {
            return i; // Retornar el índice original
        }
    }

    // Si no se encuentra el índice original, se retorna -1
    return -1;
}

private boolean guardarDatos() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("H:\\mantenimientos.csv"))) {
        for (int i = 0; i < model.getRowCount(); i++) {
            StringBuilder row = new StringBuilder();
            for (int j = 0; j < model.getColumnCount(); j++) {
                String value = model.getValueAt(i, j).toString().trim();
                // Escapar comillas y agregar comillas si hay comas
                if (value.contains(",") || value.contains("\"")) {
                    value = "\"" + value.replace("\"", "\"\"") + "\"";
                }
                row.append(value);
                if (j < model.getColumnCount() - 1) {
                    row.append(","); // Agregar coma entre columnas
                }
            }
            writer.write(row.toString());
            writer.newLine();
        }
        JOptionPane.showMessageDialog(this, "Datos guardados exitosamente. \n Regresa a la Vista General");
        return true; // Indica que se guardó exitosamente
    } catch (IOException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error al guardar los datos: " + e.getMessage());
        return false; // Indica que hubo un error
    }
}

private void eliminarRegistro() {
    int selectedRow = table.getSelectedRow();
    if (selectedRow >= 0) {
        // Obtener el índice original del modelo
        int originalRow = getOriginalRowIndex(selectedRow);
        if (originalRow < 0) {
            JOptionPane.showMessageDialog(this, "Error al encontrar el índice original.");
            return; // Salir si no se encuentra el índice
        }

        // Mostrar un cuadro de diálogo de confirmación
        int confirm = JOptionPane.showConfirmDialog(this, "¿Estás seguro de que deseas eliminar este registro?", "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            model.removeRow(originalRow); // Eliminar la fila del modelo original
            guardarDatos(); // Guardar cambios después de eliminar
            cargarDatos(); // Recargar datos para actualizar conteos
        }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione un registro para eliminar.");
    }
}

private void filtrarProximosAVencer() {
    DefaultTableModel filteredModel = new DefaultTableModel(new String[]{"EIN o TL", "Descripción", "Mantenimiento Anterior", "Fecha Mantenimiento", "Dueño del herramental", "Ubicación", "Frecuencia de mantenimiento"}, 0);
    for (int i = 0; i < model.getRowCount(); i++) {
        String fechaMantenimiento = (String) model.getValueAt(i, 3);
        if (isFechaProxima(fechaMantenimiento)) {
            filteredModel.addRow(new Object[]{
                model.getValueAt(i, 0),
                model.getValueAt(i, 1),
                model.getValueAt(i, 2),
                model.getValueAt(i, 3),
                model.getValueAt(i, 4),
                model.getValueAt(i, 5),
                model.getValueAt(i, 6)
            });
        }
    }

    if (filteredModel.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No hay mantenimientos próximos a vencer.");
    } else {
        table.setModel(filteredModel);
        aplicarRenderizadorEncabezado(); // Llama al método para centrar los encabezados
        aplicarCentrado(); // Si también necesitas centrar las celdas
    }
}

private void filtrarVencidos() {
    DefaultTableModel filteredModel = new DefaultTableModel(new String[]{"EIN o TL", "Descripción", "Mantenimiento Anterior", "Fecha Mantenimiento", "Dueño del herramental", "Ubicación", "Frecuencia de mantenimiento"}, 0);
    for (int i = 0; i < model.getRowCount(); i++) {
        String fechaMantenimiento = (String) model.getValueAt(i, 3);
        if (isFechaVencida(fechaMantenimiento)) {
            filteredModel.addRow(new Object[]{
                model.getValueAt(i, 0),
                model.getValueAt(i, 1),
                model.getValueAt(i, 2),
                model.getValueAt(i, 3),
                model.getValueAt(i, 4),
                model.getValueAt(i, 5),
                model.getValueAt(i, 6)
            });
        }
    }

    if (filteredModel.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No hay mantenimientos vencidos.");
    } else {
        table.setModel(filteredModel);
        aplicarRenderizadorEncabezado(); // Llama al método para centrar los encabezados
        aplicarCentrado(); // Si también necesitas centrar las celdas
    }
}

private void aplicarCentrado() {
    CenteredCellRenderer centeredRenderer = new CenteredCellRenderer();
    for (int i = 0; i < model.getColumnCount(); i++) {
        table.getColumnModel().getColumn(i).setCellRenderer(centeredRenderer);
    }
}

    private boolean isFechaVencida(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fechaMantenimiento = sdf.parse(fecha);
            return fechaMantenimiento.before(new Date()); // Si la fecha es anterior a hoy
        } catch (ParseException e) {
            return false;
        }
    }

    private boolean isFechaProxima(String fecha) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date fechaMantenimiento = sdf.parse(fecha);
            long diff = fechaMantenimiento.getTime() - new Date().getTime();
            long diasRestantes = diff / (1000 * 60 * 60 * 24); // Convertir a días
            return diasRestantes <= 30 && diasRestantes >= 0; // Si está dentro de los próximos 30 días
        } catch (ParseException e) {
            return false;
        }
    }

class ColorCenteredRenderer extends DefaultTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        
        // Cambiar el color según la fecha
        if (isFechaVencida((String) value)) {
            setBackground(Color.RED); // Color rojo si la fecha está vencida
        } else if (isFechaProxima((String) value)) {
            setBackground(Color.YELLOW); // Color amarillo si la fecha está próxima a vencer
        } else {
            setBackground(Color.WHITE); // Color blanco por defecto
        }

        // Cambiar el color del texto si la fila está seleccionada
        if (isSelected) {
            setForeground(Color.BLACK); // Cambiar el texto a negro si está seleccionado
        } else {
            setForeground(Color.BLACK); // Cambiar el texto a negro por defecto
        }
        
        setHorizontalAlignment(CENTER); // Centrar el texto
        return this;
    }
}

    class CenteredCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(CENTER); // Asegúrate de centrar el texto
            return c;
        }
    }
    
    private void aplicarRenderizadorEncabezado() {
    DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(JLabel.CENTER); // Centrar el texto
            setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.BLACK)); // Mantener el borde inferior
            return c;
        }
    };

    for (int i = 0; i < model.getColumnCount(); i++) {
        table.getTableHeader().getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
    }
}
               
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Lista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Lista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Lista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Lista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Lista().setVisible(true);
            }
        });
    }}
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

